package com.example.n_back_game.View;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

public class Layout extends LinearLayout {
    public Layout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        int squareSide = Math.min(width, height);
        super.onMeasure(MeasureSpec.makeMeasureSpec(squareSide, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(squareSide, MeasureSpec.EXACTLY));
        setMeasuredDimension(squareSide, squareSide);
    }
}
