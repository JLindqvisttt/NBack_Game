package com.example.n_back_game.Model;


import java.util.Random;


public class NbackLogic {

    public static final int SIZE = 3;
    private static NbackLogic nbackLogic = null;
    private int currentIndex;
    private int previousIndex;
    private int userValue;
    private int theCorrectValue;
    private int rounds;
    private int timerBetweenRound;
    private String letters [] = new String[]{"A", "B", "C", "D", "E", "F", "G", "H", "I", "J"};
    private boolean checkPressed;

    /**
     * The game of N back
     * Sets the values to its default settings
     */
    private NbackLogic() {
        rounds = 5;
        timerBetweenRound = 1;
        userValue = 0;
        previousIndex = -1;
    }

    /**
     * Singleton
     * get the instance of the object NbackLogic
     */
    public static NbackLogic getInstance() {
        if (nbackLogic == null) nbackLogic = new NbackLogic();
        return nbackLogic;
    }

    /**
     * Sets the checkPressed attribute to false or true
     */
    public void setCheckPressed(boolean checkPressed) {
        this.checkPressed = checkPressed;
    }

    /**
     * Get the rounds
     * @return the rounds
     */
    public int getRounds() {
        return rounds;
    }

    /**
     * Set the rounds
     */
    public void setRounds(int rounds) {
        this.rounds = rounds;
    }

    /**
     * Get previousIndex
     * @return the value of the previous index
     */
    public int getPreviousIndex() {
        return previousIndex;
    }

    /**
     * Get timerBetweenRound
     * @return the time that is set between per round
     */
    public int getTimerBetweenRound() {
        return timerBetweenRound;
    }

    /**
     * Set timerBetweenRound, time that is set between per round
     */
    public void setTimerBetweenRound(int timerBetweenRound) {
        this.timerBetweenRound = timerBetweenRound;
    }

    /**
     * Reset the game and restore the values to theirs start value
     */
    public void reset() {
        currentIndex = 0;
        previousIndex = -1;
        userValue = 0;
        theCorrectValue = 0;
    }

    /**
     * ticIndexVoice sets the previousIndex to the currentIndex
     * Then takes a number between 0-10 and then set the currentIndex to the new number
     * @return A String from the letters array on the new random index
     */
    public String ticIndexVoice(){
        previousIndex = currentIndex;
        Random random = new Random();
        currentIndex = random.nextInt(10);
        if (currentIndex == previousIndex) theCorrectValue++;
        return letters[currentIndex];
    }

    /**
     * ticIndex() sets the previousIndex to the currentIndex
     * Then takes a number between 0-9 and then set the currentIndex to the new number
     * @return the new currentIndex that was generated
     */
    public int ticIndex() {
        previousIndex = currentIndex;
        Random random = new Random();
        currentIndex = random.nextInt(9);
        if (currentIndex == previousIndex) theCorrectValue++;
        return currentIndex;
    }

    /**
     * This methods calls when the game is over and
     * displays the values from the game
     * @return A String of the values
     */
    @Override
    public String toString() {
        return "Game over! " +"\n" + "Your correct answers: " + userValue + "\n"+ " Correct answers: " + theCorrectValue ;
    }

    /**
     * Checks if the previous value and the current value is the same
     * @return true if the requirement is true
     * @return false if the requirement is false
     */
    public boolean checkIfSame(){
        if (previousIndex == currentIndex) return true;
        return false;
    }

    /**
     * Checks if the current value is the same as the previous value
     * and check if the button has been pressed already in that round
     * @return true if the requirement is true
     * @return false if the requirement is false
     */
    public boolean checkCorrect() {
        if (currentIndex == previousIndex && !checkPressed){
            userValue += 1;
            setCheckPressed(true);
            return true;
        }
        return false;
    }

}
