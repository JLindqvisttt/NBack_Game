package com.example.n_back_game;

import static com.example.n_back_game.Model.NbackLogic.SIZE;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.n_back_game.Model.NbackLogic;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    private Drawable square;
    private Timer timer;
    private Handler handler;
    private NbackLogic nbackLogic;
    private Button btnClicked;
    private TextView timer_text;
    private TextView round_text;
    private TextView gameover_text;
    private TextView timeBetweenRounds;
    private TextView textViewTimerCountdown;
    private int timeBetweenRoundsSeconds;
    private int currentCounterRound;
    private int timerCounting;
    private int numberOfRounds;

    /**
     * Creates the mainActivity
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.start_Button).setOnClickListener(v -> startNBackGameSquare());
        findViewById(R.id.setting_Button).setOnClickListener(v-> settings());
        findViewById(R.id.startAudio_Button).setOnClickListener(v->startNBackGameAudio());

        btnClicked = findViewById(R.id.clickedBtn);
        btnClicked.setOnClickListener(v -> checkIfCorrect());
        Resources resources = getResources();
        square = ResourcesCompat.getDrawable(resources, R.drawable.not, null);

        timer_text = findViewById(R.id.text_Time);
        round_text = findViewById(R.id.text_Round);
        gameover_text = findViewById(R.id.text_GameOver);
        timeBetweenRounds = findViewById(R.id.text_TimeBetweenRounds);
        textViewTimerCountdown = findViewById(R.id.text_countDown);

        nbackLogic = NbackLogic.getInstance();
        SharedPreferences pref = getApplicationContext().getSharedPreferences("Pref", 0);
        int roundsIndex = pref.getInt("rounds",0);
        int timeIndex = pref.getInt("timerounds",0);

        if(roundsIndex == 0) nbackLogic.setRounds(5);
        if(roundsIndex == 1) nbackLogic.setRounds(21);
        if(roundsIndex == 2) nbackLogic.setRounds(45);

        if(timeIndex == 0) nbackLogic.setTimerBetweenRound(1);
        if(timeIndex == 1) nbackLogic.setTimerBetweenRound(2);
        if(timeIndex == 2) nbackLogic.setTimerBetweenRound(4);
        if(timeIndex == 3) nbackLogic.setTimerBetweenRound(8);

        timer = null;
        timerCounting = 3;
        handler = new Handler();
        timeBetweenRoundsSeconds = nbackLogic.getTimerBetweenRound() * 2000;
        numberOfRounds = nbackLogic.getRounds();
        timer_text.setText("Rounds: " + nbackLogic.getRounds());
        timeBetweenRounds.setText("Time between rounds: " + nbackLogic.getTimerBetweenRound() + " s");
        btnClicked.setVisibility(View.GONE);
        gameover_text.setVisibility(View.GONE);


    }

    /**
     * Start the VoiceActivity view
     */
    private void startNBackGameAudio() {
        startActivity(new Intent(this,VoiceActivity.class));
    }

    /**
     * Start the Settings view
     */
    private void settings() {
        startActivity(new Intent(this,SettingActivity.class));
    }

    /**
     * Checks if it correct when the btn is pressed
     * Changing the color of the button if
     * its correct --> Green
     * Not correct --> Red
     */
    private void checkIfCorrect() {
        if (!nbackLogic.checkCorrect()){
            btnClicked.setBackgroundColor(Color.parseColor("#DC143C"));
        }
        else btnClicked.setBackgroundColor(Color.parseColor("#006400"));
    }

    /**
     * Start the Nback game if the start button is pressed
     */
    public void startNBackGameSquare() {
        btnClicked.setVisibility(View.VISIBLE);
        gameover_text.setVisibility(View.GONE);
        btnClicked.setText("Position");
        if (timer == null) {
            currentCounterRound = 1;
            nbackLogic.reset();
            gameover_text.setText("");
            for (int i = 0; i < SIZE * SIZE; i++) {
                loadReferencesToImageViews()[i].setImageDrawable(null);
            }
            timer = new Timer();
            timer.schedule(new nbackGame(), 1000, timeBetweenRoundsSeconds);
        }
    }

    /**
     * Pause the timer
     */
    @Override
    protected void onPause() {
        super.onPause();
        cancelTimer();
    }

    /**
     * Cancel the timer
     */
    private boolean cancelTimer() {
        if (timer != null) {
            timerCounting=3;
            timer.cancel();
            timer = null;
            return true;
        }
        return false;
    }

    /**
     * Controls the Game and updates it
     * Updates the logic and the view
     * This method recalls every time the time clock is ticking
     */
    private class nbackGame extends TimerTask {
        public void run() {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    if (timerCounting>0){
                        textViewTimerCountdown.setText("" +timerCounting + "");
                        timerCounting--;
                    }
                    else{
                        textViewTimerCountdown.setText("");
                        btnClicked.setBackgroundColor(Color.parseColor("#0d6efd"));
                        nbackLogic.setCheckPressed(false);
                        if (currentCounterRound <= numberOfRounds) {
                            loadReferencesToImageViews()[nbackLogic.ticIndex()].setImageDrawable(square);
                            if (!nbackLogic.checkIfSame()) loadReferencesToImageViews()[nbackLogic.getPreviousIndex()].setImageDrawable(null);
                            round_text.setText("Current Round: " + currentCounterRound);
                            currentCounterRound++;

                        } else {
                            round_text.setText("");
                            gameover_text.setVisibility(View.VISIBLE);
                            gameover_text.setText(nbackLogic.toString());
                            btnClicked.setVisibility(View.GONE);
                            onPause();
                        }
                    }
                }
            });
        }
    }

    /**
     * Updates the squares in the view by index
     * @return the imageView of the game board layout
     */
    private ImageView[] loadReferencesToImageViews() {
        ImageView[] imgViews = new ImageView[SIZE * SIZE];
        imgViews[0] = findViewById(R.id.imageView0);
        imgViews[1] = findViewById(R.id.imageView1);
        imgViews[2] = findViewById(R.id.imageView2);
        imgViews[3] = findViewById(R.id.imageView3);
        imgViews[4] = findViewById(R.id.imageView4);
        imgViews[5] = findViewById(R.id.imageView5);
        imgViews[6] = findViewById(R.id.imageView6);
        imgViews[7] = findViewById(R.id.imageView7);
        imgViews[8] = findViewById(R.id.imageView8);

        return imgViews;

    }
}