package com.example.n_back_game;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.n_back_game.Model.NbackLogic;

public class SettingActivity extends AppCompatActivity {

    private Spinner spinnerTime;
    private Spinner spinnerRounds;
    private NbackLogic nbackLogic;

    /**
     * Creates the SettingsActivity
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        findViewById(R.id.return_btn).setOnClickListener(v -> mainReturn());
        spinnerTime = (Spinner) findViewById(R.id.time);
        spinnerRounds = (Spinner) findViewById(R.id.rounds);
        nbackLogic = NbackLogic.getInstance();

        SharedPreferences pref = getApplicationContext().getSharedPreferences("Pref", 0);
        SharedPreferences.Editor editor = pref.edit();

        ArrayAdapter adapterRounds = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.Rounds));
        adapterRounds.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRounds.setAdapter(adapterRounds);
        spinnerRounds.setSelection(pref.getInt("rounds",0));


        ArrayAdapter adapterTime = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.timeBetween));
        adapterTime.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTime.setAdapter(adapterTime);
        spinnerTime.setSelection(pref.getInt("timerounds",0));


        spinnerTime.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                editor.putInt("timerounds",i);
                editor.commit();
                int timebetween = Integer.parseInt((String) spinnerTime.getSelectedItem());
                nbackLogic.setTimerBetweenRound(timebetween);
            }
        });

        spinnerRounds.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                editor.putInt("rounds",i);
                editor.commit();
                int rounds = Integer.parseInt((String) spinnerRounds.getSelectedItem());
                nbackLogic.setRounds(rounds);
            }
        });
    }

    /**
     * Returns back to the mainView
     * Start the NbackGame square view (The mainActivity)
     */
    private void mainReturn() {
        startActivity(new Intent(this, MainActivity.class));
    }
}